# Brilliance Client 0.2.0 — Quiet Excellence

Fabric client-side GUI starter for Minecraft 1.21.11, Java 21.

## Features in this source
- Right Shift opens/closes a custom black/silver ClickGUI.
- Categories: General, Render, Utility, World.
- Clickable module cards with UI-only toggle state.
- Lightweight opening fade.
- GUI does not pause single-player.

## Important
The module cards are currently UI prototypes. They do not implement gameplay features yet. Build and test before using.

## Build
Use Java 21 and Gradle with internet access. From the project root:
`gradle build`

The JAR should be created in `build/libs/`.

If Gradle fails, inspect the first compilation/dependency error; don't simply rename the ZIP to JAR.
