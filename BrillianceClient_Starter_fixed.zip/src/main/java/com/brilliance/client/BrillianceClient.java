package com.brilliance.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class BrillianceClient implements ClientModInitializer {
    public static final String MOD_NAME = "Brilliance Client";
    private static KeyBinding toggleMenuKey;
    private static boolean menuOpen = false;

    @Override
    public void onInitializeClient() {
        toggleMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.brilliance.toggle_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleMenuKey.wasPressed()) {
                menuOpen = !menuOpen;
                if (client.player != null) {
                    client.player.sendMessage(
                            net.minecraft.text.Text.literal(
                                    "§b[Brilliance] §fMenu " + (menuOpen ? "opened (starter)" : "closed")
                                            + ". GUI is the next build step."
                            ), false
                    );
                }
            }
        });
    }
}
