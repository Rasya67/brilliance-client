# Brilliance Client — starter project

Starter scaffold for a lightweight client-side Fabric mod targeting Minecraft Java 1.21.11.

## Current state
- Fabric client mod metadata and Java 21 toolchain.
- Right Shift keybinding registered.
- Pressing Right Shift prints a starter status message.
- This is **not yet a full hacked client or ClickGUI**. It is a clean starting point for adding a GUI and utility modules.

## Build
1. Install JDK 21.
2. Install Gradle, or generate a Gradle wrapper using a local Gradle installation (`gradle wrapper`).
3. Run `gradle build`.
4. The mod JAR should appear in `build/libs/`.

## Notes
- Dependency versions in `gradle.properties` should be checked against Fabric's current 1.21.11 documentation if Gradle reports resolution errors.
- Test in a separate instance first. Do not put an untested build into a main game profile.
- Sodium/Iris/Litematica compatibility is not guaranteed by this scaffold; test incrementally.
